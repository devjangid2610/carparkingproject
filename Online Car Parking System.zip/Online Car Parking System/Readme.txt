
 Run the script http://localhost/vpms2

Admin Credential
Username: admin
Password: devd

User Credential
Username: 7791884385
Password: devd

or Register a new user.