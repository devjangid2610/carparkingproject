  <footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                   
                    <div class="col-sm-12 text-center">
                        Smart Parking Booking System | IIIT Surat
                    </div>
                </div>
            </div>
        </footer>