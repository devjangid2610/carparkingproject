 <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php"><i class="menu-icon fa fa-laptop"></i>Dashboard </a>
                    </li>
					<li>
                        <a href="add-vehicle.php"> <i class="menu-icon ti-truck"></i>Book Vehicle </a>
                    </li>
					<li>
                        <a href="view-vehicle.php"> <i class="menu-icon ti-truck"></i>View Booking </a>
                    </li>

                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>
